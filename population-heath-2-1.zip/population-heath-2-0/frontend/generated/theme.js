import {applyTheme as _applyTheme} from './theme-populationheath2.0.generated.js';
export const applyTheme = _applyTheme;
