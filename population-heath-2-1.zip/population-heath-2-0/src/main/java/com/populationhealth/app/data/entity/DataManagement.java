package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class DataManagement extends AbstractEntity {

    private String lookupName;

    private String lookupInfo;

}
