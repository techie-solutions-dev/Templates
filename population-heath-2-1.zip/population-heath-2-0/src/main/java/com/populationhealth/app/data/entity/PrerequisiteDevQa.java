package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "tblPrerequisites_QA_Dev")
@Data
public class PrerequisiteDevQa extends AbstractEntity {

    @Column(name="enrichment_activity")
    private String enrichmentActivity;

    @Column(name="client")
    private String client;

    @Column(name="qa_table_name")
    private String qaTableName;

    @Column(name="qa_database_name")
    private String qaDatabaseName;

    @Column(name="qa_server_name")
    private String qaServerName;


    @Column(name="dev_table_name")
    private String devTableName;

    @Column(name="dev_database_name")
    private String devDatabaseName;

    @Column(name="dev_server_name")
    private String devServerName;

    @Column(name="createDate")
    private Long createDate;

}
