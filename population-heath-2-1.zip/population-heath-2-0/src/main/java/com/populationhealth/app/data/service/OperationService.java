package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.Operation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OperationService {

    private final OperationRepository repository;

    public OperationService(OperationRepository repository) {
        this.repository = repository;
    }

    public Optional<Operation> get(Long id) {
        return repository.findById(id);
    }

    public Operation update(Operation entity) {
        return repository.save(entity);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public Page<Operation> list(Pageable pageable) {
        return repository.findAll(pageable);
    }

    public Page<Operation> list(Pageable pageable, Specification<Operation> filter) {
        return repository.findAll(filter, pageable);
    }

    public int count() {
        return (int) repository.count();
    }

}
