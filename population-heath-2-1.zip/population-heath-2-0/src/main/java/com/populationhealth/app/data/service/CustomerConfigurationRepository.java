package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.CustomerConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CustomerConfigurationRepository
        extends
        JpaRepository<CustomerConfiguration, Long>,
        JpaSpecificationExecutor<CustomerConfiguration> {

}
