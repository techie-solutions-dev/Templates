package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.PrerequisiteDevQa;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PrerequisiteDevQaService {

    private final PrerequisiteDevQaRepository repository;

    public PrerequisiteDevQaService(PrerequisiteDevQaRepository repository) {
        this.repository = repository;
    }

    public Optional<PrerequisiteDevQa> get(Long id) {
        return repository.findById(id);
    }

    public PrerequisiteDevQa update(PrerequisiteDevQa entity) {
        return repository.save(entity);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public Page<PrerequisiteDevQa> list(Pageable pageable) {
        return repository.findAll(pageable);
    }

    public Page<PrerequisiteDevQa> list(Pageable pageable, Specification<PrerequisiteDevQa> filter) {
        return repository.findAll(filter, pageable);
    }

    public int count() {
        return (int) repository.count();
    }

}
