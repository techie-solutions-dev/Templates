package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class Operation extends AbstractEntity {

    private String operationName;

    private String operationInfo;

}
