package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.Reporting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ReportingRepository
        extends
        JpaRepository<Reporting, Long>,
        JpaSpecificationExecutor<Reporting> {

}
