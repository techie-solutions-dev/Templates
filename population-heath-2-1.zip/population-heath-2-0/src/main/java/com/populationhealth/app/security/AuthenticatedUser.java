package com.populationhealth.app.security;

import com.populationhealth.app.data.entity.User;
import com.populationhealth.app.data.service.UserRepository;
import com.vaadin.flow.spring.security.AuthenticationContext;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuthenticatedUser {

    private final UserRepository userRepository;

    private final UserDetailsServiceImpl userDetailsService;
    private final AuthenticationContext authenticationContext;

    public AuthenticatedUser(AuthenticationContext authenticationContext, UserRepository userRepository, UserDetailsServiceImpl userDetailsService) {
        this.userRepository = userRepository;
        this.authenticationContext = authenticationContext;
        this.userDetailsService = userDetailsService;
    }

    public Optional<User> get() {
        return authenticationContext.getAuthenticatedUser(UserDetails.class)
                .map(userDetails -> userDetailsService.getDummyUser(userDetails.getUsername()));
    }

    public void logout() {
        authenticationContext.logout();
    }

}
