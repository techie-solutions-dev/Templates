package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class CodeManagement extends AbstractEntity {

    private String serviceUtilizationCategories;

    private String risk;

    private String programEligibility;

    private String intervention;

    private String lifeCycleManagement;

}
