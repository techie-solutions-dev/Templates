package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
public class Campaign extends AbstractEntity {

    private String campaignName;

    private String campaignInfo;

    private String misc;

}
