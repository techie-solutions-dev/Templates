package com.populationhealth.app.views.login;

import com.populationhealth.app.security.AuthenticatedUser;
import com.vaadin.flow.component.Unit;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Footer;
import com.vaadin.flow.component.html.Header;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.login.LoginForm;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.login.LoginOverlay;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.internal.RouteUtil;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.flow.theme.lumo.LumoUtility;

import java.awt.*;

@AnonymousAllowed
@PageTitle("Login")
@Route(value = "login")
public class LoginView extends VerticalLayout implements BeforeEnterObserver {

    private final AuthenticatedUser authenticatedUser;
    LoginForm loginForm = new LoginForm();

    public LoginView(AuthenticatedUser authenticatedUser) {
        this.authenticatedUser = authenticatedUser;

        loginForm.setAction(RouteUtil.getRoutePath(VaadinService.getCurrent().getContext(), getClass()));

        LoginI18n i18n = LoginI18n.createDefault();
        i18n.getForm().setTitle("Sign In");

        i18n.getForm().setSubmit("Sign In");
        i18n.setHeader(new LoginI18n.Header());
        i18n.getHeader().setTitle("Sign In");
        i18n.getHeader().setDescription("");
        i18n.setAdditionalInformation(null);
        loginForm.setI18n(i18n);
        loginForm.addClassNames(LumoUtility.Margin.AUTO, LumoUtility.FontSize.LARGE);

        Header header = new Header();
        StreamResource imageResource = new StreamResource("healthmap-logo.png",
                () -> getClass().getResourceAsStream("/images/healthmap-logo.png"));
        com.vaadin.flow.component.html.Image image = new Image(imageResource, "HealthMap Logo");
        image.addClassName(LumoUtility.Margin.LARGE);
        image.setWidth(15, Unit.EM);
        image.setHeight(2, Unit.EM);
        header.add(image);



        Footer footer = new Footer();

        Div footerDiv = new Div();
        Span span = new Span("Copyright © 2023 HealthMap Solutions. All Rights Reserved This system is owned and managed by Healthmap Solutions. All Healthmap Solutions systems and related equipment are intended for the communication, accessing, viewing, transmission, processing, and storage of Healthmap Solutions or other authorized information only. All systems are subject to monitoring at all times to ensure proper functioning of equipment, to prevent unauthorized use and violations of statutes and security regulations, and to deter criminal activity. Accessing this system constitutes consent for such monitoring. Unauthorized access to this system may result in disciplinary action, civil litigation or criminal prosecution.");
        footerDiv.add(span);
        footer.addClassNames(LumoUtility.FontSize.XXSMALL, LumoUtility.Background.PRIMARY, LumoUtility.AlignItems.CENTER,
                LumoUtility.TextColor.PRIMARY_CONTRAST, LumoUtility.Padding.XLARGE);
        footer.add(footerDiv);

        loginForm.setForgotPasswordButtonVisible(true);

        this.expand(loginForm);
        this.setSizeFull();
        add(header, loginForm, footer);
        this.addClassNames(LumoUtility.Padding.NONE, LumoUtility.Display.FLEX);
        //setOpened(true);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (authenticatedUser.get().isPresent()) {
            // Already logged in
           // setOpened(false);
            event.forwardTo("");
        }

        loginForm.setError(event.getLocation().getQueryParameters().getParameters().containsKey("error"));
    }
}
