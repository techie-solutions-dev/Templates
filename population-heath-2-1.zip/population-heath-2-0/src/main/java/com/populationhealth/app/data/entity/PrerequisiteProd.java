package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "tblPrerequisitesProd")
@Data
public class PrerequisiteProd extends AbstractEntity {

    @Column(name="client")
    private String client;

    @Column(name="prod_table_name")
    private String prodTableName;

    @Column(name="prod_database_name")
    private String prodDatabaseName;

    @Column(name="prod_server_name")
    private String prodServerName;

    @Column(name="createDate")
    private Long createDate;

}
