package com.populationhealth.app.data;

public enum Role {
    USER, ADMIN;
}
