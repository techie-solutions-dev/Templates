package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.CodeManagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CodeManagementRepository
        extends
        JpaRepository<CodeManagement, Long>,
        JpaSpecificationExecutor<CodeManagement> {

}
