package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
public class CustomerConfiguration extends AbstractEntity {

    private String customerName;

    private String population;

    private String enrichment;

    private String ruleConfiguration;

}
