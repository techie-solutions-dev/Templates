package com.populationhealth.app.data.service;

import com.populationhealth.app.data.entity.Enrichment;
import com.populationhealth.app.data.entity.PrerequisiteProd;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface PrerequisiteProdRepository
        extends
        JpaRepository<PrerequisiteProd, Long>,
        JpaSpecificationExecutor<PrerequisiteProd> {

}
