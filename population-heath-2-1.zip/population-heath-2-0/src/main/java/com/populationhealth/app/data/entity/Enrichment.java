package com.populationhealth.app.data.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "tblEnrichmentSPsProd")
@Data
public class Enrichment extends AbstractEntity {

    @Column(name="enrichment_activity")
    private String enrichmentActivity;

    @Column(name="client")
    private String client;

    @Column(name="server")
    private String server;

    @Column(name="database")
    private String database;

    @Column(name="stored_procedure")
    private String storedProcedure;

    @Column(name="status")
    private String status;

    @Column(name="createDate")
    private Long createDate;

}
