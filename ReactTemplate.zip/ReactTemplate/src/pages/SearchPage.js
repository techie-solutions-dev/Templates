import React from 'react';
import { Typography } from '@mui/material';

function SearchPage() {
  return (
    <Typography variant="h4">
      Search Page
    </Typography>
  );
}

export default SearchPage;