import React from 'react';
import { Typography } from '@mui/material';

function StatusPage() {
  return (
    <Typography variant="h4">
      Status Page
    </Typography>
  );
}

export default StatusPage;