import React from 'react';
import { Typography } from '@mui/material';

function UtilitiesPage() {
  return (
    <Typography variant="h4">
      Utilities Page
    </Typography>
  );
}

export default UtilitiesPage;