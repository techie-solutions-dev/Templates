import React from 'react';
import { Typography } from '@mui/material';

function DSQsPage() {
  return (
    <Typography variant="h4">
      DSQs Page
    </Typography>
  );
}

export default DSQsPage;